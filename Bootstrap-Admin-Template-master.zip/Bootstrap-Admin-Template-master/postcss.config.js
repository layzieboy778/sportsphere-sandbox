export default {
  plugins: {
    autoprefixer: {},
  },
};
